<?php
namespace ThePay\Sender;

/**
 * Payment from notification.
 */
class NotificationPayment extends Payment {
	const STATE_SENDED = 2;
	const STATE_ERROR_SENDING = 4;
	const STATE_RETURNED = 6;
	const STATE_RETURNED_RECIPIENT = 11;
	const STATE_RECLAIMED = 7;
	const STATE_RECLAIMED_RETURNED = 8;
	const STATE_RECLAIMED_NOT_RETURNED = 9;
	
	/**
	 * @var integer id of payment state
	 */
	protected $state;
	/**
	 * @var string|null description of error because of which payment was not sended
	 */
	protected $errorDescription;
	/**
	 * Used only for account name notifications.
	 * Empty for payment's status change notifications.
	 * 
	 * @var string|null name of recipient account
	 */
	protected $recipientAccountName;

	/**
	 * @param \stdClass $data
	 */
	function __construct(\stdClass $data) {
		$this->setAccountPrefix($data->accountPrefix);
		$this->setAccountNumber($data->accountNumber);
		$this->setAccountBank($data->bankCode);
		$this->setAmount($data->amount);
		$this->setCurrency($data->currency);
		$this->setVs($data->vs);
		$this->setSs($data->ss);
		$this->setKs($data->ks);
		$this->setMerchantData($data->merchantData);
		$this->setDescription($data->description);
		$this->setMerchantDescription($data->merchantDescription);
		$this->state = $data->status;
		$this->errorDescription = $data->errorDescription;
		$this->setEmail($data->email);
		if(property_exists($data, 'recipientAccountName')){
			$this->recipientAccountName = $data->recipientAccountName;
		}
	}

	/**
	 * @return int
	 */
	public function getState() {
		return $this->state;
	}

	/**
	 * @return null|string
	 */
	public function getErrorDescription() {
		return $this->errorDescription;
	}

	/**
	 * @return null|string
	 */
	public function getRecipientAccountName() {
		return $this->recipientAccountName;
	}
}