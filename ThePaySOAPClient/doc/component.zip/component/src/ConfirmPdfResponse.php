<?php
namespace ThePay\Sender;

/**
 * Response for payment PDF confirm download.
 * Contains downloaded PDF if succesfull.
 */
class ConfirmPdfResponse {
	/**
	 * Wrong payment id - payment not exists in Sender service.
	 */
	const STATUS_PAYMENT_NOT_FOUND = 404;
	/**
	 * Payment was not sent. Try it again after payment is sent.
	 */
	const STATUS_PAYMENT_NOT_SENT = 405;
	/**
	 * Problem with authorization - wrong signature, merchant id etc.
	 */
	const STATUS_UNAUTHORIZED = 401;
	/**
	 * Succesfull call, confirmation was downloaded.
	 */
	const STATUS_OK = 200;
	
	/**
	 * @var int one of STATUS_* constants
	 */
	protected $status;
	/**
	 * @var string|null downloaded PDF confirmation.
	 */
	protected $pdfFile;

	/**
	 * @param int $status
	 * @param string|null $pdfFile
	 */
	public function __construct($status, $pdfFile = null) {
		$this->status = $status;
		$this->pdfFile = $pdfFile;
	}

	/**
	 * @return int one of STATUS_* constants
	 */
	public function getStatusCode() {
		return $this->status;
	}

	/**
	 * @return string status message
	 */
	public function getStatusMessage() {
		$msg = [
			static::STATUS_PAYMENT_NOT_FOUND => 'Wrong payment id - payment not exists in Sender service.',
			static::STATUS_PAYMENT_NOT_SENT => 'Payment was not sent. Try it again after payment is sent.',
			static::STATUS_UNAUTHORIZED => 'Problem with authorization - wrong signature, merchant id etc.',
			static::STATUS_OK => 'Succesfull call, confirmation was downloaded.',
		];
		return $msg[$this->getStatusCode()];
	}

	/**
	 * @return string|null downloaded PDF confirmation.
	 */
	public function getPdfFile() {
		return $this->pdfFile;
	}
}