<?php
namespace ThePay\Sender;

/**
 * Count hashes and signatures.
 */
trait Signer {
	/** @var MerchantConfig merchant's configuration */
	protected $config;
	
	/**
	 * Count hash from given data.
	 * @param array $data
	 * @return string hash
	 */
	protected function countHash(array $data) {
		$paramArr = [];
		foreach($data as $key => $val){
			$paramArr[] = $key.'='.$val;
		}
		$hashStr = implode('&', $paramArr);
		return hash('sha256', $hashStr);
	}
	
	/**
	 * @param array $data
	 * @param string $password
	 * @return string
	 */
	private function doCountSignature(array $data, $password) {
		$data['password'] = $password;
		return $this->countHash($data);
	}
	
	/**
	 * Count signature (hash with password) for payments API from given data.
	 * 
	 * @param array $data
	 * @return string signature
	 */
	protected function countSignature(array $data) {
		return $this->doCountSignature($data, $this->config->getPassword());
	}
	
	/**
	 * Count signature (hash with password) for Data API from given data.
	 * 
	 * @param array $data
	 * @return string signature
	 */
	protected function countSignatureDataApi(array $data) {
		return $this->doCountSignature($data, $this->config->getDataApiPassword());
	}
}