<?php
namespace ThePay\Sender;

/**
 * Handle incoming notification SOAP calls.
 */
class NotificationReceiver {
	const STATUS_OK = 'OK';
	const STATUS_ERROR = 'ERROR';
	
	/**
	 * @var MerchantConfig merchant's configuration
	 */
	protected $config;	
	/**
	 * Received notification.
	 * @var Notification
	 */
	protected $notification;

	/**
	 * @param MerchantConfig $config
	 */
	function __construct(MerchantConfig $config) {
		$this->config = $config;
	}

	/**
	 * SOAP callback function for handling notification request.
	 * @param \stdClass $parameters
	 * @return \stdClass
	 */
	protected function handleNotification(\stdClass $parameters) {
		$this->notification = new Notification(
			$this->config,
			$parameters->merchantId,
			$parameters->accountId,
			$parameters->payments->payment,
			$parameters->signature
		);
		
		$response = new \stdClass;
		$response->status = self::STATUS_OK;
		return $response;
	}

	/**
	 * SOAP callback function for handling payment stus change notification request.
	 *
	 * @param \stdClass $parameters
	 * @return \stdClass
	 */
	public function sentPayments(\stdClass $parameters) {
		return $this->handleNotification($parameters);
	}
	
	/**
	 * SOAP callback function for handling account name notification request.
	 *
	 * @param \stdClass $parameters
	 * @return \stdClass
	 */
	public function accountName(\stdClass $parameters) {
		return $this->handleNotification($parameters);
	}

	/**
	 * @return Notification
	 */
	function getNotification() {
		return $this->notification;
	}
}