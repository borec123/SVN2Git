<?php
namespace ThePay\Sender;

/**
 * Configuration for sender gate.
 */
class MerchantConfig {
	/**
	 * ID of merchant in the ThePay Sender system.
	 * @var integer
	 */
	protected $merchantId;

	/**
	 * ID of your account, which you can create in the ThePay administration interface.
	 * You can have multiple accounts under one merchant.
	 * @var integer
	 */
	protected $accountId;

	/**
	 * Communication password for account. You can find it in administrations.
	 * Password is unique for each accountId. 
	 * @var string 
	 */
	protected $password;
	
	/**
	 * Communication password for Data API. You can find it in administrations.
	 * This password is same for all merchant's accounts.
	 * @var string
	 */
	protected $dataApiPassword;
	
	/**
	 * URL of WSDL document for payment sending webservice API.
	 * @var string
	 */
	protected $paymentsWsdl;

	/**
	 * URL of WSDL document for notification receiving webservice API.
	 * @var string
	 */
	protected $notificationsWsdl;

	/**
	 * URL of WSDL document for account name notification receiving webservice API.
	 * @var string
	 */
	protected $notificationsAccountNameWsdl;

	/**
	 * URL for downloading PDF confirmations of sent payment.
	 * @var string
	 */
	protected $downloadConfirmPdfUrl;

	/**
	 * URL for downloading payments export.
	 * @var string
	 */
	protected $downloadPaymentsExport;
	
	/**
	 * URL of WSDL document for Data API.
	 * @var string
	 */
	protected $dataApiWsdl;

	/**
	 * @param bool $production
	 * @param int $merchantId
	 * @param int $accountId
	 * @param string $password
	 * @param string $dataApiPassword
	 */
	public function __construct($production = false, $merchantId = 1, $accountId = 1, $password = 'test', $dataApiPassword = 'test_data') {

		$this->setMerchantId($merchantId)
			->setAccountId($accountId)
			->setPassword($password)
			->setDataApiPassword($dataApiPassword);

		if ($production) {
			$this->setPaymentsWsdl('https://www.thepay.cz/sender-gate/api/payments-api.wsdl')
				->setNotificationsWsdl('https://www.thepay.cz/sender-gate/api/payments-sent-api.wsdl')
				->setNotificationsAccountNameWsdl('https://www.thepay.cz/sender-gate/api/payments-account-name.wsdl')
				->setDataApiWsdl('https://www.thepay.cz/sender-gate/api/data/data-v1.wsdl');
		} else {
			$this->setPaymentsWsdl('https://www.thepay.cz/sender-demo-gate/api/payments-api-demo.wsdl')
				->setNotificationsWsdl('https://www.thepay.cz/sender-demo-gate/api/payments-sent-api-demo.wsdl')
				->setNotificationsAccountNameWsdl('https://www.thepay.cz/sender-demo-gate/api/payments-account-name-demo.wsdl')
				->setDataApiWsdl('https://www.thepay.cz/sender-demo-gate/api/data/data-v1-demo.wsdl');
		}

		$this->setDownloadConfirmPdfUrl('https://www.thepay.cz/sender-gate/admin/obchodnik/api/download_confirm/');
		$this->setDownloadPaymentsExport('https://www.thepay.cz/sender-gate/admin/obchodnik/api/download_export/');
	}

	/**
	 * @param int $merchantId
	 * @return $this
	 */
	public function setMerchantId($merchantId) {
		$this->merchantId = $merchantId;
		return $this;
	}

	/**
	 * @param int $accountId
	 * @return $this
	 */
	public function setAccountId($accountId) {
		$this->accountId = $accountId;
		return $this;
	}

	/**
	 * @param string $password
	 * @return $this
	 */
	public function setPassword($password) {
		$this->password = $password;
		return $this;
	}

	/**
	 * @param string $dataApiPassword
	 * @return $this
	 */
	public function setDataApiPassword($dataApiPassword) {
		$this->dataApiPassword = $dataApiPassword;
		return $this;
	}

	/**
	 * @param string $paymentsWsdl
	 * @return $this
	 */
	public function setPaymentsWsdl($paymentsWsdl) {
		$this->paymentsWsdl = $paymentsWsdl;
		return $this;
	}

	/**
	 * @param string $notificationsWsdl
	 * @return $this
	 */
	public function setNotificationsWsdl($notificationsWsdl) {
		$this->notificationsWsdl = $notificationsWsdl;
		return $this;
	}

	/**
	 * @param string $notificationsAccountNameWsdl
	 * @return $this
	 */
	public function setNotificationsAccountNameWsdl($notificationsAccountNameWsdl) {
		$this->notificationsAccountNameWsdl = $notificationsAccountNameWsdl;
		return $this;
	}

	/**
	 * @param string $downloadConfirmPdfUrl
	 * @return $this
	 */
	public function setDownloadConfirmPdfUrl($downloadConfirmPdfUrl) {
		$this->downloadConfirmPdfUrl = $downloadConfirmPdfUrl;
		return $this;
	}

	/**
	 * @param string $dataApiWsdl
	 * @return $this
	 */
	function setDataApiWsdl($dataApiWsdl) {
		$this->dataApiWsdl = $dataApiWsdl;
		return $this;
	}
	
	/**
	 * @param string $downloadPaymentsExport
	 * @return $this
	 */
	public function setDownloadPaymentsExport($downloadPaymentsExport) {
		$this->downloadPaymentsExport = $downloadPaymentsExport;
		return $this;
	}

	/**
	 * @return int
	 */
	public function getMerchantId() {
		return $this->merchantId;
	}

	/**
	 * @return int
	 */
	public function getAccountId() {
		return $this->accountId;
	}

	/**
	 * @return string
	 */
	public function getPassword() {
		return $this->password;
	}

	/**
	 * @return string
	 */
	public function getDataApiPassword() {
		return $this->dataApiPassword;
	}

	/**
	 * @return string
	 */
	public function getPaymentsWsdl() {
		return $this->paymentsWsdl;
	}

	/**
	 * @return string
	 */
	public function getNotificationsWsdl() {
		return $this->notificationsWsdl;
	}

	/**
	 * @return string
	 */
	public function getNotificationsAccountNameWsdl() {
		return $this->notificationsAccountNameWsdl;
	}

	/**
	 * @return string
	 */
	public function getDownloadConfirmPdfUrl() {
		return $this->downloadConfirmPdfUrl;
	}
	
	/**
	 * @return string
	 */
	public function getDataApiWsdl() {
		return $this->dataApiWsdl;
	}
	
	/**
	 * @return string
	 */
	public function getDownloadPaymentsExport() {
		return $this->downloadPaymentsExport;
	}
}
