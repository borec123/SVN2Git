<?php
namespace ThePay\Sender;

/**
 * Response for payment export download.
 * Contains file with export if succesfull.
 * 
 * @author Michal Kandr
 */
class DownloadExportResponse {
	/**
	 * Succesfull call, export was downloaded
	 */
	const STATUS_OK = 200;
	/**
	 * Wrong parameters ("from" or "to" date)
	 */
	const STATUS_BAD_REQUEST = 400;
	/**
	 * Problem with authorization - wrong signature, merchant id etc.
	 */
	const STATUS_UNAUTHORIZED = 401;
	/**
	 * Merchant does not exist or is inactive
	 */
	const STATUS_MERCHANT_NOT_FOUND = 404;
	
	/**
	 * @var int one of STATUS_* constants
	 */
	protected $status;
	/**
	 * @var string|null downloaded export file
	 */
	protected $exportFile;

	/**
	 * @param int $status
	 * @param string|null $exportFile
	 */
	public function __construct($status, $exportFile = null) {
		$this->status = $status;
		$this->exportFile = $exportFile;
	}

	/**
	 * @return int one of STATUS_* constants
	 */
	public function getStatusCode() {
		return $this->status;
	}

	/**
	 * @return string status message
	 */
	public function getStatusMessage() {
		$msg = [
			static::STATUS_OK => 'Succesfull call, export was downloaded.',
			static::STATUS_BAD_REQUEST => 'Wrong parameters ("from" or "to" date)',
			static::STATUS_UNAUTHORIZED => 'Problem with authorization - wrong signature, merchant id etc.',
			static::STATUS_MERCHANT_NOT_FOUND => 'Merchant does not exist or is inactive.',
			
		];
		return $msg[$this->getStatusCode()];
	}

	/**
	 * @return string|null downloaded export
	 */
	public function getExportFile() {
		return $this->exportFile;
	}
}