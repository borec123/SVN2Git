<?php
namespace ThePay\Sender;

/**
 *
 * @author Michal Kandr
 */
class PaymentRequest {
	use Signer;
	
	/**
	 * @var MerchantConfig merchant's configurations
	 */
	protected $config;
	/**
	 * @var Payment[] payments to send
	 */
	protected $payments;
	
	/**
	 * @param MerchantConfig $config
	 * @param Payment[] $payments
	 */
	public function __construct(MerchantConfig $config, array $payments) {
		$this->config = $config;
		$this->payments = $payments;
	}

	/**
	 * @return string
	 */
	protected function getSignature() {
		$paymentHashes = [];
		foreach ($this->payments as $payment){
			$paymentHashes[] = $payment->getHash();
		}
		return $this->countSignature([
			'merchantId' => $this->config->getMerchantId(),
			'accountId' => $this->config->getAccountId(),
			'payments' => implode('|', $paymentHashes),
		]);
	}

	/**
	 * @return array
	 */
	public function getForRequest() {
		$payments = [];
		foreach($this->payments as $payment){
			$payments[] = $payment->getForRequest();
		}
		return ['parameters' => [
			'merchantId' => $this->config->getMerchantId(),
			'accountId' => $this->config->getAccountId(),
			'payments' => $payments,
			'signature' => $this->getSignature(),
		]];
	}
}
