<?php
namespace ThePay\Sender;

/**
 * Handle API communication with ThePay.
 */
class SenderHelper {
	use Signer;
	
	/**
	 * @var MerchantConfig merchant's configuration
	 */
	protected $config;

	/**
	 * @param MerchantConfig $config
	 */
	function __construct(MerchantConfig $config) {
		$this->config = $config;
	}

	/**
	 * @param PaymentRequest $request request for send to ThePay gate
	 * @return PaymentResponse response returned from ThePay
	 * @throws SenderException
	 */
	public function sendPayments(PaymentRequest $request) {
		$client = new \SoapClient($this->config->getPaymentsWsdl());
		try{
			$response = call_user_func_array([$client, 'sendPayments'], $request->getForRequest());
		} catch (\SoapFault $e){
			throw new SenderException('SoapFault during sendPayments call', null, $e);
		}
		if( ! $response){
			throw new SenderException('sendPayments response is empty');
		}
		$result = new PaymentResponse($this->config, $response);
		return $result;
	}

	/**
	 * @return MerchantConfig
	 */
	public function getConfig() {
		return $this->config;
	}

	/**
	 * Receive notification using given WSDL.
	 * @param string $wsdl
	 * @return Notification received notification
	 */
	protected function doReceiveNotification($wsdl) {
		$server = new \SoapServer($wsdl, ['uri' => $wsdl, 'features' => SOAP_SINGLE_ELEMENT_ARRAYS]);
		$receiver = new NotificationReceiver($this->config);
		$server->setObject($receiver);
		$server->handle();
		return $receiver->getNotification();
	}
	
	/**
	 * Receive notification from ThePay
	 * @return Notification received notification
	 */
	public function receiveNotification() {
		return $this->doReceiveNotification($this->config->getNotificationsWsdl());
	}
	
	/**
	 * Receive account name notification from ThePay
	 * @return Notification received notification
	 */
	public function receiveAccountNameNotification() {
		return $this->doReceiveNotification($this->config->getNotificationsAccountNameWsdl());
	}
	
	/**
	 * Create CURL handle and inicialize it's parameters.
	 * @param string $url URL to be called
	 * @return resource
	 */
	protected function createCurlHandle($url){
		$handle = curl_init();
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($handle, CURLOPT_HEADER, 1);
		curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($handle, CURLOPT_URL, $url);
		return $handle;
	}

	/**
	 * Do PDF confirmation download from given URL.
	 * @param string $url final URL
	 * @return ConfirmPdfResponse
	 * @throws SenderException
	 */
	protected function doDownloadConfirmPdf($url){
		// call URL
		$handle = $this->createCurlHandle($url);
		$response = curl_exec($handle);
		// cURL error
		if ($response === false) {
			throw new SenderException("CURL error [" . curl_errno($handle) . "]: " . curl_error($handle));
		}
		// HTTP code = result of call
		$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
		$file = null;
		// successful call, response body is PDF confirmation
		if($httpCode == ConfirmPdfResponse::STATUS_OK){
			$file = substr( $response, curl_getinfo($handle,CURLINFO_HEADER_SIZE) );
		}
		
		curl_close($handle);
		
		return new ConfirmPdfResponse($httpCode, $file);
	}

	/**
	 * Download PDF confirmation of sent payment.
	 * @param integer $paymentId id of payment
	 * @return ConfirmPdfResponse
	 * @throws SenderException
	 */
	public function downloadConfirmPdfById($paymentId) {
		//build URL
		$sign = $this->countSignatureDataApi([
			'paymentId' => $paymentId,
			'merchantId' => $this->config->getMerchantId(),
		]);
		$url = $this->config->getDownloadConfirmPdfUrl().(int)$paymentId.'/'.$sign.'/';
		return $this->doDownloadConfirmPdf($url);
	}
	
	/**
	 * Download PDF confirmation of sent payment by MerchantData.
	 * @param integer $merchantData MerchantData of payment
	 * @return ConfirmPdfResponse
	 * @throws SenderException
	 */
	public function downloadConfirmPdfByMerchantData($merchantData) {
		//build URL
		$sign = $this->countSignatureDataApi([
			'merchantData' => $merchantData,
			'merchantId' => $this->config->getMerchantId(),
			'accountId' => $this->config->getAccountId(),
		]);
		$url = $this->config->getDownloadConfirmPdfUrl()
			.'merchant_data/'
			.$this->config->getAccountId().'/'
			.urlencode($merchantData).'/'
			.$sign.'/';
		return $this->doDownloadConfirmPdf($url);
	}
	
	/**
	 * Download export with payments for given period.
	 * @param \DateTime $from
	 * @param \DateTime $to
	 * 
	 * @return DownloadExportResponse
	 * @throws SenderException
	 */
	public function downloadPaymentsExport(\DateTime $from, \DateTime $to){
		//build URL
		$sign = $this->countSignatureDataApi([
			'merchantId' => $this->config->getMerchantId(),
			'format' => 'gpc',
			'from' => $from->format('Y-m-d'),
			'to' => $to->format('Y-m-d'),
		]);
		$url = $this->config->getDownloadPaymentsExport()
			.$this->config->getMerchantId().'/'
			.'gpc/'
			.$from->format('Y-m-d').'/'
			.$to->format('Y-m-d').'/'
			.$sign.'/';
		
		// call URL
		$handle = $this->createCurlHandle($url);
		$response = curl_exec($handle);
		// cURL error
		if ($response === false) {
			throw new SenderException("CURL error [" . curl_errno($handle) . "]: " . curl_error($handle));
		}
		// HTTP code = result of call
		$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
		$file = null;
		// successful call, response body is PDF confirmation
		if($httpCode == DownloadExportResponse::STATUS_OK){
			$file = substr( $response, curl_getinfo($handle,CURLINFO_HEADER_SIZE) );
		}
		
		curl_close($handle);
		
		return new DownloadExportResponse($httpCode, $file);
	}
	
	/**
	 * @param PaymentRequest $request request for send to ThePay gate
	 * @return GetBalanceResponse response returned from ThePay
	 * @throws SenderException
	 */
	public function getBalance() {
		$client = new \SoapClient($this->config->getDataApiWsdl(), ['trace' => true]);
		$requestData = [
			'merchantId' => $this->config->getMerchantId(),
		];
		$requestData['signature'] = $this->countSignatureDataApi($requestData);
		try{
			$response = $client->getBalance($requestData);
		} catch (\SoapFault $e){
			throw new SenderException('SoapFault during getBalance call', null, $e);
		}
		if( ! $response){
			throw new SenderException('getBalance response is empty');
		}
		$result = new GetBalanceResponse($this->config, $response);
		return $result;
	}
}