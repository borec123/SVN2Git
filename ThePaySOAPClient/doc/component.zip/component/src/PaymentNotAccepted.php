<?php
namespace ThePay\Sender;

/**
 * Payment which was not accepted by payment gate because of some error;
 * 
 */
class PaymentNotAccepted {
	use Signer;
	
	/** @var string arbitrary merchan't data used for identification of payment by merchant */
	protected $merchantData;
	/** @var string detail description of error. */
	protected $errorDescription;

	/**
	 * @param \stdClass $data
	 */
	function __construct(\stdClass $data) {
		$this->merchantData = $data->merchantData;
		$this->errorDescription = $data->errorDescription;
	}

	/**
	 * @return string
	 */
	public function getMerchantData() {
		return $this->merchantData;
	}

	/**
	 * @return string
	 */
	public function getErrorDescription() {
		return $this->errorDescription;
	}

	/**
	 * @return string
	 */
	public function getHash() {
		return $this->countHash([
			'merchantData' => $this->merchantData,
			'errorDescription' => $this->errorDescription,
		]);
	}
}
