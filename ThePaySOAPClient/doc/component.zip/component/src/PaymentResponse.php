<?php
namespace ThePay\Sender;

/**
 * Response for payment send request returned by ThePay gate.
 * 
 */
class PaymentResponse {
	use Signer;
	
	const STATUS_OK = 'OK';
	const STATUS_ERROR_REQUEST = 'ERROR_REQUEST';
	const STATUS_ERROR_PAYMENTS = 'ERROR_PAYMENTS';
	
	/** @var MerchantConfig merchant's configuration */
	protected $config;
	
	/** @var integer */
	protected $merchantId;
	/** @var integer */
	protected $accountId;
	/** @var string one of STATUS_* constants */
	protected $status;
	/** @var string */
	protected $errorDescription;
	/** @var PaymentNotAccepted[] */
	protected $notAcceptedPayments;
	/** @var string */
	protected $signature;

	/**
	 * @param MerchantConfig $config
	 * @param \stdClass $data
	 */
	public function __construct(MerchantConfig $config, \stdClass $data) {
		$this->config = $config;
		$this->merchantId = $data->merchantId;
		$this->accountId = $data->accountId;
		$this->status = $data->status;
		$this->errorDescription = $data->errorDescription;
		$this->notAcceptedPayments = [];
		if( $data->notAcceptedPayments){
			foreach( $data->notAcceptedPayments as $payment){
				$this->notAcceptedPayments[] = new PaymentNotAccepted($payment);
			}
		}
		$this->signature = $data->signature;
	}

	/**
	 * @return int
	 */
	public function getMerchantId() {
		return $this->merchantId;
	}

	/**
	 * @return int
	 */
	public function getAccountId() {
		return $this->accountId;
	}

	/**
	 * @return string
	 */
	public function getStatus() {
		return $this->status;
	}

	/**
	 * @return string
	 */
	public function getErrorDescription() {
		return $this->errorDescription;
	}

	/**
	 * @return array|PaymentNotAccepted[]
	 */
	public function getNotAcceptedPayments() {
		return $this->notAcceptedPayments;
	}

	/**
	 * @return string
	 */
	public function getSignature() {
		return $this->signature;
	}

	/**
	 * @return string
	 */
	protected function countDataSignature() {
		$data = [
			'merchantId' => $this->merchantId,
			'accountId' => $this->accountId,
			'status' => $this->status,
		];
		if($this->errorDescription){
			$data['errorDescription'] = $this->errorDescription;
		}
		if($this->notAcceptedPayments){
			$paymentHashes = [];
			foreach ($this->notAcceptedPayments as $payment){
				$paymentHashes[] = $payment->getHash();
			}
			$data['notAcceptedPayments'] = implode('|', $paymentHashes);
		}
		if($this->status == self::STATUS_ERROR_REQUEST){
			return $this->countHash($data);
		} else {
			return $this->countSignature($data);
		}
	}

	/**
	 * @return boolean check if request signature valid
	 */
	public function isValid() {
		return $this->merchantId == $this->config->getMerchantId()
			&& $this->accountId = $this->config->getAccountId()
			&& $this->countDataSignature() == $this->getSignature();
	}
}
