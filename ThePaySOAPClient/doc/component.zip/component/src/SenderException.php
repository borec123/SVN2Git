<?php
namespace ThePay\Sender;

class SenderException extends \Exception {
}
