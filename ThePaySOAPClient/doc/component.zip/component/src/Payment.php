<?php
namespace ThePay\Sender;
/**
 * Payment for sende by Sender.
 */
class Payment {
	use Signer;
	
	/** @var string account prefix, can be empty */
	protected $accountPrefix;
	/** @var string account number */
	protected $accountNumber;
	/** @var string code of bank */
	protected $accountBank;
	/** @var float amount to be send */
	protected $amount;
	/** @var integer id of currency */
	protected $currency;
	/** @var string variable symbol */
	protected $vs;
	/** @var string specific symbol */
	protected $ss;
	/** @var string constatnt symbol */
	protected $ks;
	/** @var string description for receiver */
	protected $description;
	/** @var string arbitrary merchan't data used for identification of payment by merchant */
	protected $merchantData;
	/** @var string internal merchant description invisible to customer */
	protected $merchantDescription;
	/** @var string e-mail of receiver, notification about payment will be send to it */
	protected $email;

	/**
	 * @param string $accountPrefix
	 * @return $this
	 */
	public function setAccountPrefix($accountPrefix) {
		$this->accountPrefix = $accountPrefix;
		return $this;
	}

	/**
	 * @param string $accountNumber
	 * @return $this
	 */
	public function setAccountNumber($accountNumber) {
		$this->accountNumber = $accountNumber;
		return $this;
	}

	/**
	 * @param string $accountBank
	 * @return $this
	 */
	public function setAccountBank($accountBank) {
		$this->accountBank = $accountBank;
		return $this;
	}

	/**
	 * @param float $amount
	 * @return $this
	 */
	public function setAmount($amount) {
		$this->amount = $amount;
		return $this;
	}

	/**
	 * @param int $currency
	 * @return $this
	 */
	public function setCurrency($currency) {
		$this->currency = $currency;
		return $this;
	}

	/**
	 * @param string $vs
	 * @return $this
	 */
	public function setVs($vs) {
		$this->vs = $vs;
		return $this;
	}

	/**
	 * @param string $ss
	 * @return $this
	 */
	public function setSs($ss) {
		$this->ss = $ss;
		return $this;
	}

	/**
	 * @param string $ks
	 * @return $this
	 */
	public function setKs($ks) {
		$this->ks = $ks;
		return $this;
	}

	/**
	 * @param string $description
	 * @return $this
	 */
	public function setDescription($description) {
		$this->description = $description;
		return $this;
	}

	/**
	 * @param string $merchantData
	 * @return $this
	 */
	public function setMerchantData($merchantData) {
		$this->merchantData = $merchantData;
		return $this;
	}

	/**
	 * @param string $merchantDescription
	 * @return $this
	 */
	public function setMerchantDescription($merchantDescription) {
		$this->merchantDescription = $merchantDescription;
		return $this;
	}

	/**
	 * @param string $email
	 * @return $this
	 */
	function setEmail($email) {
		$this->email = $email;
		return $this;
	}

	/**
	 * @return string
	 */
	public function getAccountPrefix() {
		return $this->accountPrefix;
	}

	/**
	 * @return string
	 */
	public function getAccountNumber() {
		return $this->accountNumber;
	}

	/**
	 * @return string
	 */
	public function getAccountBank() {
		return $this->accountBank;
	}

	/**
	 * @return float
	 */
	public function getAmount() {
		return $this->amount;
	}

	/**
	 * @return int
	 */
	public function getCurrency() {
		return $this->currency;
	}

	/**
	 * @return string
	 */
	public function getVs() {
		return $this->vs;
	}

	/**
	 * @return string
	 */
	public function getSs() {
		return $this->ss;
	}

	/**
	 * @return string
	 */
	public function getKs() {
		return $this->ks;
	}

	/**
	 * @return string
	 */
	public function getDescription() {
		return $this->description;
	}

	/**
	 * @return string
	 */
	public function getMerchantData() {
		return $this->merchantData;
	}

	/**
	 * @return string
	 */
	public function getMerchantDescription() {
		return $this->merchantDescription;
	}

	/**
	 * @return string
	 */
	public function getEmail() {
		return $this->email;
	}

	/**
	 * @return string
	 */
	public function getHash() {
		$data = $this->getForRequest();
		$data['amount'] = number_format($data['amount'], 2, '.', '');
		return $this->countHash($data);
	}

	/**
	 * @return array
	 */
	public function getForRequest() {
		$data = [
			'accountPrefix' => $this->accountPrefix,
			'accountNumber' => $this->accountNumber,
			'bankCode' => $this->accountBank,
			'amount' => $this->amount,
			'currency' => $this->currency,
			'vs' => $this->vs,
			'ss' => $this->ss,
			'ks' => $this->ks,
			'merchantData' => $this->merchantData,
			'description' => $this->description,
			'merchantDescription' => $this->merchantDescription,
			'email' => $this->email,
		];
		return array_filter($data);
	}
}