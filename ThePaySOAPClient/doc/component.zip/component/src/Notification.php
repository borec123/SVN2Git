<?php
namespace ThePay\Sender;

/**
 * Notification request received from by ThePay gate after payments are send.
 * 
 */
class Notification {
	use Signer;
	
	/** @var MerchantConfig merchant's configuration */
	protected $config;
	
	/** @var integer */
	protected $merchantId;
	/** @var integer */
	protected $accountId;
	/** @var NotificationPayment[] */
	protected $payments = [];
	/** @var string */
	protected $signature;

	/**
	 * @param MerchantConfig $config
	 * @param int $merchantId
	 * @param int $accountId
	 * @param \stdClass[] $payments
	 * @param string $signature
	 */
	public function __construct(MerchantConfig $config, $merchantId, $accountId, $payments, $signature) {
		$this->config = $config;
		$this->merchantId = $merchantId;
		$this->accountId = $accountId;

		foreach($payments as $payment){
			$this->payments[] = new NotificationPayment($payment);
		}

		$this->signature  = $signature;
	}

	/**
	 * @return int
	 */
	public function getMerchantId() {
		return $this->merchantId;
	}

	/**
	 * @return int
	 */
	public function getAccountId() {
		return $this->accountId;
	}

	/**
	 * @return NotificationPayment[]
	 */
	public function getPayments() {
		return $this->payments;
	}

	/**
	 * @return string
	 */
	public function getSignature(){
		return $this->signature;
	}

	/**
	 * @return string
	 */
	protected function countDataSignature(){
		$paymentHashes = [];
		foreach ($this->payments as $payment){
			$paymentHashes[] = $payment->getHash();
		}
		return $this->countSignature([
			'merchantId' => $this->merchantId,
			'accountId' => $this->accountId,
			'payments' => implode('|', $paymentHashes)
		]);
	}

	/**
	 * @return boolean check if request signature is valid
	 */
	public function isValid(){
		return $this->merchantId == $this->config->getMerchantId()
			&& $this->accountId = $this->config->getAccountId()
			&& $this->countDataSignature() == $this->getSignature();
	}
}
