<?php
namespace ThePay\Sender;

/**
 * Response for getBalance request.
 * Contains merchant's balances for payment methods (banks).
 */
class GetBalanceResponse {
	use Signer;
	
	const STATUS_OK = 'OK';
	const STATUS_ERROR = 'ERROR';
	
	/** @var MerchantConfig merchant's configuration */
	protected $config;
	
	/** @var integer */
	protected $merchantId;
	/** @var string one of STATUS_* constants */
	protected $status;
	/** @var string */
	protected $errorDescription;
	/** @var MethodBalance */
	protected $balances;
	/** @var string */
	protected $signature;
	
	/**
	 * @param MerchantConfig $config
	 * @param \stdClass $data
	 */
	public function __construct(MerchantConfig $config, \stdClass $data) {
		$this->config = $config;
		$this->merchantId = $data->merchantId;
		$this->status = $data->status;
		if( ! empty($data->errorDescription)){
			$this->errorDescription = $data->errorDescription;
		}
		$this->balances = [];
		if( $data->balances){
			foreach( $data->balances as $balance){
				$this->balances[] = new MethodBalance($balance);
			}
		}
		$this->signature = $data->signature;
	}
	
	function getConfig() {
		return $this->config;
	}

	function getMerchantId() {
		return $this->merchantId;
	}

	function getStatus() {
		return $this->status;
	}

	function getErrorDescription() {
		return $this->errorDescription;
	}

	function getBalances() {
		return $this->balances;
	}

	function getSignature() {
		return $this->signature;
	}

	/**
	 * @return string
	 */
	protected function countDataSignature() {
		if($this->status == self::STATUS_ERROR && !$this->signature){
			return null;
		}
		$data = [
			'merchantId' => $this->merchantId,
			'status' => $this->status,
		];
		if($this->errorDescription){
			$data['errorDescription'] = $this->errorDescription;
		}
		if($this->balances){
			$balanceHashes = [];
			foreach ($this->balances as $balance){
				$balanceHashes[] = $balance->getHash();
			}
			$data['balances'] = implode('|', $balanceHashes);
		}
		return $this->countSignatureDataApi($data);
	}

	/**
	 * @return boolean check if request signature valid
	 */
	public function isValid() {
		return $this->merchantId == $this->config->getMerchantId()
			&& $this->countDataSignature() == $this->getSignature();
	}
}