<?php
namespace ThePay\Sender;

/**
 * Balance for payment method. Used in GetBalanceResponse class.
 */
class MethodBalance {
	use Signer;
	
	/** @var integer */
	protected $methodId;
	/** @var integer */
	protected $methodName;
	/** @var float */
	protected $balance;
	/** @var integer */
	protected $currency;
	
	/**
	 * @param array $data
	 */
	function __construct(array $data) {
		$this->methodId = $data['methodId'];
		$this->methodName = $data['methodName'];
		$this->balance = $data['balance'];
		$this->currency = $data['currency'];
	}
	
	function getMethodId() {
		return $this->methodId;
	}

	function getMethodName() {
		return $this->methodName;
	}

	function getBalance() {
		return $this->balance;
	}

	function getCurrency() {
		return $this->currency;
	}

	/**
	 * @return string
	 */
	public function getHash() {
		return $this->countHash([
			'methodId' => $this->methodId,
			'methodName' => $this->methodName,
			'balance' => number_format($this->balance, 2, '.', ''),
			'currency' => $this->currency,
		]);
	}
}