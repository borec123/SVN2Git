## v2.4
* Data API
	- downloading GPC payments export

## v2.3
* Data API
	- downloading PDF confirmation by merchantData (method)
	- rename method downloadConfirmPdf to downloadConfirmPdfById

## v2.2
* Data API - new method - get actual balance

## v2.1.2
* MerchantConfig - change order of constructor parameters
* ConfirmPdfResponse - add human readable status messages

## v2.1.1
* fluent setters
* setters and constructor in MerchantConfig
* getters in Payment

## v2.1.0
* Data API - download payment confirmation PDF
* refactoring
    * namespaces
    * class reorganization
    * code improvements
    * composer support